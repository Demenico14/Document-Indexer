import { supabase } from '@/lib/supabase'
import { v4 as uuid } from 'uuid'

export async function POST(req: Request) {
  const formData = await req.formData()
  const file = formData.get('file') as File

  const fileName = `${uuid()}-${file.name}`

  const { error } = await supabase.storage
    .from(process.env.SUPABASE_BUCKET!)
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
    })

  if (error) {
    return new Response(JSON.stringify({ error }), { status: 500 })
  }

  const { data } = supabase.storage
    .from(process.env.SUPABASE_BUCKET!)
    .getPublicUrl(fileName)

  return new Response(JSON.stringify({ url: data.publicUrl }), {
    headers: { 'Content-Type': 'application/json' },
  })
}
